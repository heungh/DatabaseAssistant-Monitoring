import streamlit as st
from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, AIMessage

# Streamlit 앱 설정
st.set_page_config(page_title="Claude 3 Chat App", page_icon="🤖")
st.title("Claude 3 Chat App")

# ChatBedrock 인스턴스 생성
@st.cache_resource
def get_chat_model():
    return ChatBedrock(
        model_id="anthropic.claude-3-sonnet-20240229-v1:0",
        model_kwargs={"temperature": 0.7, "max_tokens": 4096}
    )

chat = get_chat_model()

# 세션 상태 초기화
if "messages" not in st.session_state:
    st.session_state.messages = []
if "mode" not in st.session_state:
    st.session_state.mode = "context"
if "context_window" not in st.session_state:
    st.session_state.context_window = 5

# 사이드바에 대화 모드 선택 옵션 추가
st.sidebar.title("대화 설정")
st.session_state.mode = st.sidebar.radio("대화 모드", ["context", "single"])
st.session_state.context_window = st.sidebar.slider("컨텍스트 윈도우 크기", 1, 10, 5)

# 대화 초기화 버튼
if st.sidebar.button("대화 초기화"):
    st.session_state.messages = []
    st.experimental_rerun()

# 채팅 히스토리 표시
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# 사용자 입력 처리
if prompt := st.chat_input("Claude 3에게 무엇을 물어보시겠습니까?"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # Claude 3 응답 생성
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""
        
        if st.session_state.mode == "context":
            # 컨텍스트 모드: 최근 N개의 메시지 사용
            recent_messages = st.session_state.messages[-st.session_state.context_window:]
        else:
            # 단일 질문 모드: 현재 질문만 사용
            recent_messages = [st.session_state.messages[-1]]
        
        messages = [
            HumanMessage(content=msg["content"]) if msg["role"] == "user"
            else AIMessage(content=msg["content"])
            for msg in recent_messages
        ]
        
        for chunk in chat.stream(messages):
            full_response += chunk.content
            message_placeholder.markdown(full_response + "▌")
        
        message_placeholder.markdown(full_response)
    
    st.session_state.messages.append({"role": "assistant", "content": full_response})

# 디버그 정보 (옵션)
if st.sidebar.checkbox("디버그 정보 표시"):
    st.sidebar.write("현재 모드:", st.session_state.mode)
    st.sidebar.write("컨텍스트 윈도우 크기:", st.session_state.context_window)
    st.sidebar.write("총 메시지 수:", len(st.session_state.messages))