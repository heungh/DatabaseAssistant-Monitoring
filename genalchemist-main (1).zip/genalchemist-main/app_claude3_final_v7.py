import streamlit as st
from pathlib import Path
import pandas as pd
import mysql.connector
import boto3
import json
import re
import os
import requests
from datetime import datetime
import csv
from io import StringIO
import datetime
from botocore.exceptions import ClientError
import time
import logging
from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, AIMessage
from streamlit.web import cli as stcli
from streamlit import runtime
import sys

region_val = "us-east-1"

# Initialize logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

st.title("Aurora MySQL Database Management Demo with Claude3")


def format_text(text):
    # 여러 줄의 공백을 하나의 줄바꿈으로 대체
    text = re.sub(r"\n\s*\n", "\n", text)

    # '•' 기호 앞에 줄바꿈 추가 (첫 번째 '•' 제외)
    text = re.sub(r"(?<!^)\s*•", "\n•", text)

    # 각 '•' 항목 들여쓰기
    lines = text.split("\n")
    formatted_lines = []
    for line in lines:
        if line.strip().startswith("•"):
            formatted_lines.append(line)
        else:
            formatted_lines.append("  " + line)

    return "\n".join(formatted_lines)


# ChatBedrock instance creation
@st.cache_resource
def get_chat_model():
    return ChatBedrock(
        model_id="anthropic.claude-3-sonnet-20240229-v1:0",
        model_kwargs={"temperature": 0.7, "max_tokens": 4096},
    )


chat = get_chat_model()

# Session state initialization
if "messages" not in st.session_state:
    st.session_state.messages = []
if "mode" not in st.session_state:
    st.session_state.mode = "context"
if "context_window" not in st.session_state:
    st.session_state.context_window = 5

# Sidebar configuration
st.sidebar.title("Chat Settings")
st.session_state.mode = st.sidebar.radio("Chat Mode", ["context", "single"])
st.session_state.context_window = st.sidebar.slider("Context Window Size", 1, 10, 5)

# Reset conversation button
if st.sidebar.button("Reset Conversation"):
    st.session_state.messages = []
    st.experimental_rerun()

# Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# User input processing


# Debug information
if st.sidebar.checkbox("Show Debug Info"):
    st.sidebar.write("Current Mode:", st.session_state.mode)
    st.sidebar.write("Context Window Size:", st.session_state.context_window)
    st.sidebar.write("Total Messages:", len(st.session_state.messages))


# Helper functions
def process_tool_call(tool_name, tool_input):
    if tool_name == "get_price":
        return get_price(tool_input["fruit"])
    elif tool_name == "get_database_info":
        return get_database_info(tool_input["secret_name"])
    elif tool_name == "execute_sql":
        return execute_sql(tool_input["secret_name"], tool_input["user_query"])
    elif tool_name == "execute_sql_multiDatabase":
        return execute_sql_multiDatabase(
            tool_input["keyword"], tool_input["user_query"]
        )
    elif tool_name == "compare_database_info":
        return compare_database_info(tool_input["keyword"])
    elif tool_name == "retrieve_perf_metric_multiDatabase":
        return retrieve_perf_metric_multiDatabase(
            tool_input["keyword"],
            tool_input["start_time"],
            tool_input["end_time"],
            tool_input["user_query"],
        )
    elif tool_name == "query_athena_table":
        return query_athena_table(tool_input["database_name"], tool_input["user_query"])
    elif tool_name == "check_cpu_overload":
        return query_athena_table(tool_input["database_name"], tool_input["user_query"])
    elif tool_name == "explain_plan_query":
        return explain_plan_query(tool_input["keyword"], tool_input["user_query"])


def interact_with_llm(secret_name, query):
    client = boto3.client("bedrock-runtime")
    model_Id = "anthropic.claude-3-sonnet-20240229-v1:0"
    accept = "application/json"
    contentType = "application/json"

    # Fetch Database Information Dynamically
    schema_context = get_database_info(secret_name)
    schema_context += "generate a sql command between <begin sql> and </end sql>"
    print("-----interact_with_llm:get_database_info:schema_context: ", schema_context)

    prompt_data = f"""Human: You're expert Aurora mysql DBA and you can answer any question all about Aurora mysql.
                             In case you don't have the information in context provided, please respond with 'I don't know' 
                             Don't use keywords ''if exists'' when you drop index and 
                             Just write sqls like ''drop index idx_products on products!
                             And don't generate sqls in Korean! But you can tell only explanations in Korean when you are asked in Korean.
                             Don't explain about query and just write sql!
                             Use <context> when generating sql. In the <context>, there are schema information such as tables,columns,indexes.
                             Just write exact column and table name from exact tables and colums based on <context>.
                             If you are asked about listing top query ,then use sql between <example> and </example> and use erformance_schema.events_statements_summary_by_digest when generating sql based on it please.
                             Don't use duplicate column and just leave one!
                             If you get duplicate columns from another tables, add different alias. refer alias query in <example>
                             If you get query or queries as prompt input, you just return prompt input as it is please.
    <context>
    {schema_context}
    </context>
    <example>
    --alias query 
    SELECT p.ProductID, p.ProductName, p.Price, p.StockQuantity, p.CategoryID, p.tag, p.new_column, p.tag2, p.tag3,
       c.CustomerID, c.FirstName, c.LastName, c.Email, c.Address, c.Phone,
       o.OrderID, o.CustomerID as o_CustomerID, o.ProductID as o_ProductID, o.Quantity, o.OrderDate, o.TotalPrice
    FROM products p
    JOIN orders o ON p.ProductID = o.ProductID
    JOIN customers c ON o.CustomerID = c.CustomerID;
    
    --merged colum query / sum and order query
    SELECT CONCAT(c.FirstName, ' ', c.LastName) AS customer_name,
       o.OrderDate,
       p.ProductName,
       SUM(o.Quantity * p.Price) AS total_order_amt
    FROM orders o
    JOIN customers c ON o.CustomerID = c.CustomerID
    JOIN products p ON o.ProductID = p.ProductID
    GROUP BY customer_name, o.OrderDate, p.ProductName
    ORDER BY total_order_amt DESC; 
    
    --top query
    SELECT digest_text, count_star, sum_rows_examined, sum_created_tmp_disk_tables, sum_no_index_used  
    FROM performance_schema.events_statements_summary_by_digest
    ORDER BY SUM_TIMER_WAIT DESC, count_star DESC, 
             sum_rows_examined DESC,sum_no_index_used DESC, 
             sum_created_tmp_disk_tables DESC;
    </example>
    <question>
    {query}
    </question>
    Assistant:"""

    claude_input = json.dumps(
        {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1024,
            "messages": [
                {"role": "user", "content": [{"type": "text", "text": prompt_data}]}
            ],
            "temperature": 0.5,
            "top_k": 250,
            "top_p": 1,
            "stop_sequences": [],
        }
    )

    response = client.invoke_model(modelId=model_Id, body=claude_input)
    response_body = json.loads(response.get("body").read())
    print("------prompt:", prompt_data)

    try:
        message = response_body.get("content", [])
        result = message[0]["text"]
    except (KeyError, IndexError):
        result = "I'm sorry, I couldn't generate a response."

    print("interact_with_llm result:", result)
    return result


def interact_with_general_llm(user_request):
    client = boto3.client("bedrock-runtime")
    model_Id = "anthropic.claude-3-sonnet-20240229-v1:0"

    prompt_data = f"""Human: You're expert Aurora mysql DBA and you can answer any question all about Aurora mysql.
                             In case you don't have the information in context provided, please respond with 'I don't know' 
                             You can analyze the query plan and order of plan and explain details easily with schema information.
    
    <question>
    {user_request}
    </question>
    Assistant:"""

    claude_input = json.dumps(
        {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1024,
            "messages": [
                {"role": "user", "content": [{"type": "text", "text": prompt_data}]}
            ],
            "temperature": 0.5,
            "top_k": 250,
            "top_p": 1,
            "stop_sequences": [],
        }
    )

    response = client.invoke_model(modelId=model_Id, body=claude_input)
    response_body = json.loads(response.get("body").read())
    print("------prompt:", prompt_data)

    try:
        message = response_body.get("content", [])
        result = message[0]["text"]
    except (KeyError, IndexError):
        result = "I'm sorry, I couldn't generate a response."

    print("interact_with_general llm result:", result)
    return result


def interact_with_llm_athena(database_name, query):
    client = boto3.client("bedrock-runtime")
    model_Id = "anthropic.claude-3-sonnet-20240229-v1:0"

    # Fetch Database Information Dynamically
    schema_context = """TABLE performance_insights_data 
                            cluster_id string,
                            instance_id string,
                            metric string,
                            timestamp string,
                            value double
                        
                        TABLE enhanced_monitoring_data
                            cluster_id string,
                            instance_id string,
                            metric string,
                            timestamp string,
                            value double
                        TABLE enhanced_monitoring_data' Data: metric column has value CPUUtilization and FreeableMemory
                     """
    print("schema_context", schema_context)
    schema_context += (
        "generate a sql command between <begin sql> and </end sql> refer example!"
    )

    prompt_data = f"""Human: You're expert Aws athena expert data analyst and query specialist of athena and you can answer any question all about athena query.
                             But query will be given in natural language and you can convert it with right sqls with context.
                               In case you don't have the information in context provided, please respond with 'I don't know'.
                               Like example,  you can write query like SELECT dbcluster, timestamp,metric FROM enhanced_metric talbe WHERE condition with context;
                               ,your can write query select sum(metric) from metric tables where dbcluster = 'gamedb1-cluster'
                               Please refer example below  
                               If it is needed, you can write nested query like example select ... from (select ... from ) where avg_cpu_per >=5;
                               in situation "list up db clusters which has cpu ulitization metrc with values more than 60 percent. 
                               In that case, refer example2
                               
                               
    <context>
    {schema_context}
    </context>
    <example1> 
        SELECT cluster_id, instance_id,
                        ROUND(AVG(CASE WHEN metric = 'CPUUtlization' THEN value else 0 END),2) AS avg_cpu_per,
                        ROUND(AVG(CASE WHEN metric = 'FreeableMemory' THEN (value/1024/1024/1024) else 0 END),2) AS avg_freeMemory_gb
                FROM enhanced_monitoring_data
                WHERE timestamp BETWEEN '2024-06-19 22:00' AND '2024-06-19 23:00'
                GROUP BY cluster_id, instance_id
                ORDER BY avg_cpu_per DESC, avg_freeMemory_gb ASC;
    </example1>
    <example2>
         SELECT cluster_id, instance_id,avg_cpu_per,avg_freeMemory_gb
         FROM (
                SELECT cluster_id, instance_id,
                        ROUND(AVG(CASE WHEN metric = 'CPUUtlization' THEN value else 0 END),2) AS avg_cpu_per,
                        ROUND(AVG(CASE WHEN metric = 'FreeableMemory' THEN (value/1024/1024/1024) else 0 END),2) AS avg_freeMemory_gb
                FROM enhanced_monitoring_data
                WHERE timestamp BETWEEN '2024-06-19 22:00' AND '2024-06-19 23:00'
                GROUP BY cluster_id, instance_id
                ORDER BY avg_cpu_per DESC, avg_freeMemory_gb ASC 
             )
        WHERE avg_cpu_per >=5;
    </example2>
    <question>
    {query}
    </question>
    Assistant:"""

    print("prompt_data:", prompt_data)
    claude_input = json.dumps(
        {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1024,
            "messages": [
                {"role": "user", "content": [{"type": "text", "text": prompt_data}]}
            ],
            "temperature": 0.5,
            "top_k": 250,
            "top_p": 1,
            "stop_sequences": [],
        }
    )

    response = client.invoke_model(modelId=model_Id, body=claude_input)
    response_body = json.loads(response.get("body").read())

    try:
        message = response_body.get("content", [])
        result = message[0]["text"]
    except (KeyError, IndexError):
        result = "I'm sorry, I couldn't generate a response."

    return result


# New function to interact with Knowledge Base
def query_knowledge_base(kb_id, query):
    client = boto3.client("bedrock-agent-runtime")
    try:
        response = client.retrieve(
            knowledgeBaseId=kb_id,
            retrievalQuery={"text": query},
            retrievalConfiguration={
                "vectorSearchConfiguration": {"numberOfResults": 3}
            },
        )
        return response["retrievalResults"]
    except Exception as e:
        logger.error(f"Error querying Knowledge Base: {str(e)}")
        return []


def chat_with_claude(user_message, tool_config):
    client = boto3.client("bedrock-runtime")
    model_Id = "anthropic.claude-3-sonnet-20240229-v1:0"

    # Query Knowledge Base
    kb_id = "YHPMN4YLJY"  # Replace with your actual Knowledge Base ID
    kb_results = query_knowledge_base(kb_id, user_message)

    # Prepare context from Knowledge Base results
    kb_context = ""
    for result in kb_results:
        if "content" in result and isinstance(result["content"], dict):
            if "text" in result["content"]:
                kb_context += result["content"]["text"] + "\n\n"
        elif isinstance(result, dict) and "text" in result:
            kb_context += result["text"] + "\n\n"

    user_message += kb_context
    messages = [{"role": "user", "content": [{"text": user_message}]}]

    response = client.converse(
        modelId=model_Id, messages=messages, toolConfig=tool_config
    )

    output_message = response["output"]["message"]
    messages.append(output_message)
    stop_reason = response["stopReason"]

    if stop_reason == "tool_use":
        # Tool use requested. Call the tool and send the result to the model.
        tool_requests = response["output"]["message"]["content"]
        for tool_request in tool_requests:
            if "toolUse" in tool_request:
                tool = tool_request["toolUse"]
                print("----toolname : ", tool["name"])
                result = ""
                if tool["name"] == "get_price":
                    tool_result = {}
                    result = get_price(tool["input"]["fruit"])
                    tool_result = {
                        "toolUseId": tool["toolUseId"],
                        "content": [{"json": {"price": result}}],
                    }
                    tool_result_message = {
                        "role": "user",
                        "content": [{"toolResult": tool_result}],
                    }
                    messages.append(tool_result_message)
                    # Send the tool result to the model.
                    response = client.converse(
                        modelId=model_Id, messages=messages, toolConfig=tool_config
                    )
                    output_message = response["output"]["message"]
                elif tool["name"] == "get_database_info":
                    tool_result = {}
                    result = get_database_info(tool["input"]["secret_name"])
                    tool_result = {
                        "toolUseId": tool["toolUseId"],
                        "content": [{"json": {"info": result}}],
                    }
                    tool_result_message = {
                        "role": "user",
                        "content": [{"toolResult": tool_result}],
                    }
                    messages.append(tool_result_message)
                    # Send the tool result to the model.
                    response = client.converse(
                        modelId=model_Id, messages=messages, toolConfig=tool_config
                    )
                    output_message = response["output"]["message"]
                elif tool["name"] == "execute_sql":
                    tool_result = {}
                    execute_sql(
                        tool["input"]["secret_name"], tool["input"]["user_query"]
                    )
                    tool_result = {
                        "toolUseId": tool["toolUseId"],
                        "content": [{"json": {"result": result}}],
                    }
                    tool_result_message = {
                        "role": "user",
                        "content": [{"toolResult": tool_result}],
                    }
                    messages.append(tool_result_message)
                    # Send the tool result to the model.
                    response = client.converse(
                        modelId=model_Id, messages=messages, toolConfig=tool_config
                    )
                    output_message = response["output"]["message"]
                elif tool["name"] == "execute_sql_multiDatabase":
                    tool_result = {}
                    execute_sql_multiDatabase(
                        tool["input"]["keyword"], tool["input"]["user_query"]
                    )
                    tool_result = {
                        "toolUseId": tool["toolUseId"],
                        "content": [{"json": {"result": result}}],
                    }
                    tool_result_message = {
                        "role": "user",
                        "content": [{"toolResult": tool_result}],
                    }
                    messages.append(tool_result_message)
                    # Send the tool result to the model.
                    response = client.converse(
                        modelId=model_Id, messages=messages, toolConfig=tool_config
                    )
                    output_message = response["output"]["message"]
                elif tool["name"] == "compare_database_info":
                    tool_result = {}
                    compare_database_info(tool["input"]["keyword"])
                    tool_result = {
                        "toolUseId": tool["toolUseId"],
                        "content": [{"json": {"result": result}}],
                    }
                    tool_result_message = {
                        "role": "user",
                        "content": [{"toolResult": tool_result}],
                    }
                    messages.append(tool_result_message)
                    # Send the tool result to the model.
                    response = client.converse(
                        modelId=model_Id, messages=messages, toolConfig=tool_config
                    )
                    output_message = response["output"]["message"]
                elif tool["name"] == "retrieve_perf_metric_multiDatabase":
                    tool_result = {}
                    retrieve_perf_metric_multiDatabase(
                        tool["input"]["keyword"],
                        tool["input"]["start_time"],
                        tool["input"]["end_time"],
                        tool["input"]["user_query"],
                    )
                    tool_result = {
                        "toolUseId": tool["toolUseId"],
                        "content": [{"json": {"result": result}}],
                    }
                    tool_result_message = {
                        "role": "user",
                        "content": [{"toolResult": tool_result}],
                    }
                    messages.append(tool_result_message)
                    # Send the tool result to the model.
                    response = client.converse(
                        modelId=model_Id, messages=messages, toolConfig=tool_config
                    )
                    output_message = response["output"]["message"]
                elif tool["name"] == "query_athena_table":
                    tool_result = {}
                    query_athena_table(
                        tool["input"]["database_name"], tool["input"]["user_query"]
                    )
                    tool_result = {
                        "toolUseId": tool["toolUseId"],
                        "content": [{"json": {"result": result}}],
                    }
                    tool_result_message = {
                        "role": "user",
                        "content": [{"toolResult": tool_result}],
                    }
                    messages.append(tool_result_message)
                    # Send the tool result to the model.
                    response = client.converse(
                        modelId=model_Id, messages=messages, toolConfig=tool_config
                    )
                    output_message = response["output"]["message"]
                elif tool["name"] == "explain_plan_query":
                    tool_result = {}
                    explain_plan_query(
                        tool["input"]["keyword"], tool["input"]["user_query"]
                    )
                    tool_result = {
                        "toolUseId": tool["toolUseId"],
                        "content": [{"json": {"result": result}}],
                    }
                    tool_result_message = {
                        "role": "user",
                        "content": [{"toolResult": tool_result}],
                    }
                    messages.append(tool_result_message)

                    # Send the tool result to the model.
                    response = client.converse(
                        modelId=model_Id, messages=messages, toolConfig=tool_config
                    )
                    output_message = response["output"]["message"]
    else:
        # Send the tool result to the model.
        # print("messages-------:",messages)
        messages = user_message
        claude_input = json.dumps(
            {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 4096,
                "messages": [
                    {"role": "user", "content": [{"type": "text", "text": messages}]}
                ],
                "temperature": 0.5,
                "top_k": 250,
                "top_p": 1,
                "stop_sequences": [],
            }
        )

        response = client.invoke_model(modelId=model_Id, body=claude_input)
        response_body = json.loads(response.get("body").read())

        print(response_body)

        try:
            message = response_body.get("content", [])
            result = message[0]["text"]
        except (KeyError, IndexError):
            result = "I'm sorry, I couldn't generate a response."
        st.write(result)


# Initialize AWS clients
rds_client = boto3.client(service_name="rds")
pi_client = boto3.client(service_name="pi")
cw_client = boto3.client(service_name="cloudwatch")
athena_client = boto3.client("athena")

# Database configuration
database_name = "sales"
pi_table_name = "performance_insights_data"
em_table_name = "enhanced_monitoring_data"
s3_bucket_name = "using-genai-for-private-files-workshopoutputbucket-xi57to3uszjx"
s3_bucket_path = f"s3://{s3_bucket_name}/{database_name}"
s3_bucket_table_em_path = f"{s3_bucket_path}/data/enhanced_monitoring_data"
s3_bucket_table_pi_path = f"{s3_bucket_path}/data/performance_insight_monitoring_data"
s3_bucket_meta_path = f"{s3_bucket_path}/meta"


def get_price(fruit):
    if fruit == "apple":
        return "100"
    elif fruit == "orange":
        return "80"


# get_database_info 에서 호출
def connect_to_db(secret_name):
    # Fetch the secret values
    secret_values = get_secret(secret_name)
    print("---------secret_values:", secret_values)
    # try:

    connection = mysql.connector.connect(
        host=secret_values["host"],
        user=secret_values["username"],
        password=secret_values["password"],
        port=secret_values["port"],
        database=secret_values["dbname"],
    )
    return connection
    # except Exception as e:
    #    print(f"Database connect Error: {e}")
    #    return None


# get_database_info 에서 호출
def get_secret(secret_name):
    # Initialize a session using Amazon Secrets Manager
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager")

    # Get the secret value
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    secret = get_secret_value_response["SecretString"]
    return json.loads(secret)


# get_database_info 에서 호출
def save_to_s3(secret_name, metadata_info):
    s3 = boto3.client("s3")
    bucket_name = "using-genai-for-private-files-workshopoutputbucket-xi57to3uszjx"  # 버킷 이름 설정

    # 현재 날짜와 시간을 포함한 폴더 이름 생성
    # now = datetime.now()
    folder_name = secret_name  # {now.strftime('%Y%m%d_%H%M%S')}"

    # 데이터베이스 정보를 문자열로 변환
    metadata_info_str = "".join(metadata_info)

    # 기존 폴더 확인 및 삭제
    prefix = f"{folder_name}/"
    existing_objects = s3.list_objects(Bucket=bucket_name, Prefix=prefix)
    if "Contents" in existing_objects:
        for obj in existing_objects["Contents"]:
            s3.delete_object(Bucket=bucket_name, Key=obj["Key"])
        print(f"Existing folder '{folder_name}' deleted.")
    else:
        print(f"No existing folder found for '{folder_name}'.")

    # S3에 파일 업로드
    file_name = f"{folder_name}.txt"
    s3.put_object(
        Body=metadata_info_str.encode("utf-8"),
        Bucket=bucket_name,
        Key=f"{folder_name}/{file_name}",
    )

    print(
        f"Database information for {secret_name} uploaded to S3 bucket '{bucket_name}' in folder '{folder_name}'"
    )


def get_database_info(secret_name):
    secret_values = get_secret(secret_name)
    connection = mysql.connector.connect(
        host=secret_values["host"],
        user=secret_values["username"],
        password=secret_values["password"],
        port=secret_values["port"],
        database=secret_values["dbname"],
    )

    cursor = connection.cursor()
    cursor.execute("SELECT DATABASE();")  #
    database_name = cursor.fetchone()
    # 데이터베이스 내 모든 테이블 정보 가져오기
    cursor.execute(
        f"SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, COLUMN_COMMENT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '{database_name[0]}' ORDER BY TABLE_NAME, ORDINAL_POSITION"
    )
    table_info = cursor.fetchall()

    # 테이블 정보를 문자열로 변환
    table_info_str = "Database has following tables and columns: \n"
    current_table = None
    for row in table_info:
        table_name, column_name, data_type, column_comment = row

        if table_name != current_table:
            if current_table:
                table_info_str += "\n"
            table_info_str += f"{table_name} with columns:\n"
            current_table = table_name
        table_info_str += f"{column_name} {data_type} {column_comment}\n"

    # 인덱스 정보 가져오기
    cursor.execute(
        f"SELECT TABLE_NAME, INDEX_NAME, COLUMN_NAME, NON_UNIQUE, INDEX_COMMENT FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = '{database_name[0]}' ORDER BY TABLE_NAME, INDEX_NAME"
    )
    index_info = cursor.fetchall()

    index_info_str = "\nIndexes:\n"
    current_table = None
    for row in index_info:
        table_name, index_name, column_name, non_unique, index_comment = row
        if table_name != current_table:
            if current_table:
                index_info_str += "\n"
            index_info_str += f"{table_name}:\n"
            current_table = table_name
        index_info_str += f"  {index_name} ({column_name}) {'' if non_unique else 'UNIQUE'} {index_comment}\n"

    # 프라이머리 키 정보 가져오기
    cursor.execute(
        f"SELECT TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = '{database_name[0]}' AND CONSTRAINT_NAME LIKE 'PRIMARY%' ORDER BY TABLE_NAME"
    )
    primary_key_info = cursor.fetchall()

    primary_key_info_str = "\nPrimary Keys:\n"
    current_table = None
    for row in primary_key_info:
        table_name, column_name, constraint_name = row
        if table_name != current_table:
            if current_table:
                primary_key_info_str += "\n"
            primary_key_info_str += f"{table_name}:\n"
            current_table = table_name
        primary_key_info_str += f"  {constraint_name} ({column_name})\n"

    # 외래 키 정보 가져오기
    cursor.execute(
        f"SELECT TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = '{database_name[0]}' AND REFERENCED_TABLE_NAME IS NOT NULL ORDER BY TABLE_NAME, CONSTRAINT_NAME"
    )
    foreign_key_info = cursor.fetchall()

    foreign_key_info_str = "\nForeign Keys:\n"
    current_table = None
    for row in foreign_key_info:
        (
            table_name,
            column_name,
            constraint_name,
            referenced_table_name,
            referenced_column_name,
        ) = row
        if table_name != current_table:
            if current_table:
                foreign_key_info_str += "\n"
            foreign_key_info_str += f"{table_name}:\n"
            current_table = table_name
        foreign_key_info_str += f"  {constraint_name} ({column_name}) REFERENCES {referenced_table_name}({referenced_column_name})\n"

    # 프로시저 정보 가져오기
    cursor.execute(
        f"SELECT ROUTINE_NAME, ROUTINE_COMMENT FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA = '{database_name[0]}' AND ROUTINE_TYPE = 'PROCEDURE' ORDER BY ROUTINE_NAME"
    )
    procedure_info = cursor.fetchall()

    procedure_info_str = "\nProcedures:\n"
    for procedure_name, procedure_comment in procedure_info:
        procedure_info_str += f"  {procedure_name} {procedure_comment}\n"

    # 함수 정보 가져오기
    cursor.execute(
        f"SELECT ROUTINE_NAME, ROUTINE_COMMENT FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA = '{database_name[0]}' AND ROUTINE_TYPE = 'FUNCTION' ORDER BY ROUTINE_NAME"
    )
    function_info = cursor.fetchall()

    function_info_str = "\nFunctions:\n"
    for function_name, function_comment in function_info:
        function_info_str += f"  {function_name} {function_comment}\n"

    # 파티션 테이블 정보 가져오기
    cursor.execute(
        f"SELECT TABLE_NAME, PARTITION_NAME, PARTITION_METHOD, PARTITION_EXPRESSION, PARTITION_COMMENT FROM INFORMATION_SCHEMA.PARTITIONS WHERE TABLE_SCHEMA = '{database_name[0]}' ORDER BY TABLE_NAME, PARTITION_ORDINAL_POSITION"
    )
    partition_info = cursor.fetchall()

    partition_info_str = "\nPartitioned Tables:\n"
    current_table = None
    for row in partition_info:
        (
            table_name,
            partition_name,
            partition_method,
            partition_expression,
            partition_comment,
        ) = row
        if table_name != current_table:
            if current_table:
                partition_info_str += "\n"
            partition_info_str += f"{table_name}:\n"
            current_table = table_name
        partition_info_str += f"  {partition_name} ({partition_method} {partition_expression}) {partition_comment}\n"

    # 시스템 뷰 정보 가져오기
    cursor.execute(
        f"SELECT TABLE_NAME, VIEW_DEFINITION, CHECK_OPTION, IS_UPDATABLE, DEFINER, SECURITY_TYPE FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_SCHEMA = '{database_name[0]}' ORDER BY TABLE_NAME"
    )
    system_view_info = cursor.fetchall()

    # 퍼포먼스 스키마 뷰 정보 가져오기
    cursor.execute(
        "SELECT TABLE_NAME, TABLE_TYPE, ENGINE, TABLE_COMMENT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' ORDER BY TABLE_NAME"
    )
    performance_schema_info = cursor.fetchall()

    performance_schema_info_str = "\nPerformance Schema Views:\n"
    for table_name, table_type, engine, table_comment in performance_schema_info:
        performance_schema_info_str += f"{table_name}: {table_comment}\n"

    # print("performance_schema_info_str \n")
    # print(performance_schema_info_str)

    # 모든 메타데이터 정보 결합
    metadata_info = (
        table_info_str
        + index_info_str
        + primary_key_info_str
        + foreign_key_info_str
        + procedure_info_str
        + function_info_str
        + partition_info_str
    )  # + performance_schema_info_str
    results = metadata_info.split("'")

    print("--------results:", results)
    cursor.close()
    # S3에 데이터베이스 정보 저장
    save_to_s3(secret_name, results)
    return metadata_info


def execute_sql(secret_name, user_query):
    if user_query:

        llm_response = interact_with_llm(secret_name, user_query)
        # Convert multiline llm_response to single line
        # st.write(f"LLM Response: {llm_response}")
        print("-------execute_sql:secret_name:", secret_name)
        print("-------execute_sql:llm_response:", llm_response)
        # Extract SQL command from LLM response
        sql_command_match = re.search(
            r"<begin sql>(.*?)<\s?/end sql>", llm_response, re.DOTALL | re.IGNORECASE
        )
        # sql_command_match = re.sub("\n", "", sql_command_match)
        print("------execute_sql:sql_commands_match:", sql_command_match)

        if sql_command_match:
            sql_command = sql_command_match.group(1).strip()

            query_list = [q.strip() for q in sql_command.split(";") if q.strip()]

            print(
                "------execute_sql:if sql_command_match: ",
                sql_command + f" on database : {secret_name}",
            )
            try:

                connection = connect_to_db(secret_name)
                if connection:
                    print("connect")

                cursor = connection.cursor()

                for i, query in enumerate(query_list):
                    print(f"Executing query {i+1}:-----")
                    cursor.execute(query)
                    if cursor.with_rows:
                        columns = cursor.column_names
                        results = cursor.fetchall()
                        df = pd.DataFrame(results, columns=columns)
                        st.write(f"Results for Query {i+1}:")
                        st.write(df)
                    else:
                        st.write(
                            f"Query {i+1} executed successfully: {cursor.rowcount} rows affected."
                        )

                # 너비를 최대 200자리로 설정
                pd.set_option("display.max_rows", 200)
                # 최대 열 수를 20으로 설정
                pd.set_option("display.max_columns", 20)
                # 전체 너비를 200자리로 설정
                pd.set_option("display.width", 200)

            except Exception as e:
                print(f"Error executing SQL command: {e}")
        else:
            st.warning("No SQL command found in LLM response.")
            print("No SQL command found in LLM response.")


# execute_sql_multiDatabase 에서 호출
def get_secrets_by_keyword(keyword):
    secrets_manager = boto3.client(service_name="secretsmanager")
    response = secrets_manager.list_secrets(
        Filters=[{"Key": "name", "Values": [keyword]}]
    )
    return [secret["Name"] for secret in response["SecretList"]]


def execute_sql_multiDatabase(keyword, user_query):
    secret_lists = get_secrets_by_keyword(keyword)
    for secret_name in secret_lists:
        st.write("On the cluster ", secret_name, ", these workloads will be executed: ")
        execute_sql(secret_name, user_query)


# compare_database_info 에서 호출
def read_file_from_s3(bucket_name, folder_name, file_name):
    s3 = boto3.client("s3")
    try:
        obj = s3.get_object(Bucket=bucket_name, Key=f"{folder_name}/{file_name}")
        file_content = obj["Body"].read().decode("utf-8")
        return file_content
    except Exception as e:
        print(f"Error reading file from S3: {e}")
        st.error(f"Error reading file from S3: {e}")
        return None


# compare_database_info 에서 호출
def interact_with_llm_for_comparison(query):
    client = boto3.client("bedrock-runtime")
    model_Id = "anthropic.claude-3-sonnet-20240229-v1:0"
    accept = "application/json"
    contentType = "application/json"

    prompt_data = f"""Human: In case you don't have the information 
                  in context provided, please respond with 'I don't know' 
                  Compare the database information provided in the given text files and highlight any differences in tables, columns, indexes, primary keys, foreign keys, procedures, functions, or partitioned tables across the files.
                  When you tell about file name, dont' say like first file ,second file , instead, use exact file name,which is also s3 folder and s3 file name.
                  Just say "gamedb1-cluster" instead of s3://gamedb1-cluster.txt  
                  Remove  "s3://" and ".txt" in response please!
                  And finally, summarize it in one sentence please!
        <example>
              For example, say like an example below. 
              Based on the information provided in the text files, here are the differences across the databases:
              1.Tables: The database gamedb1-cluster has an additional table called 'customer_product_orders' and a backup table called 'products_backup' which are not present in the other two databases.
              2.Columns: The table 'products' in 's3://gamedb1-cluster.txt' and 's3://gamedb3-cluster.txt' has a 'Description' column which is missing in 'gamedb2-cluster'.
              3.Indexes: The database  'gamedb1-cluster' has an additional index 'ix_order_date' on the 'OrderDate' column of the 'orders' table, which is not present in the other two databases.
        </example>
        <question>
            {query}
        </question>
            Assistant:"""

    claude_input = json.dumps(
        {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1024,
            "messages": [
                {"role": "user", "content": [{"type": "text", "text": prompt_data}]}
            ],
            "temperature": 0.5,
            "top_k": 250,
            "top_p": 1,
            "stop_sequences": [],
        }
    )

    response = client.invoke_model(modelId=model_Id, body=claude_input)
    response_body = json.loads(response.get("body").read())

    # print(response_body)

    try:
        message = response_body.get("content", [])
        result = message[0]["text"]
    except (KeyError, IndexError):
        result = "I'm sorry, I couldn't generate a response."

    # print("result:",result)
    return result


def compare_database_info(keyword):
    bucket_name = "using-genai-for-private-files-workshopoutputbucket-xi57to3uszjx"
    file_contents = []

    secret_lists = get_secrets_by_keyword(keyword)
    print("secret_lists :", secret_lists)
    for secret_name in secret_lists:
        metainfo = get_database_info(secret_name)
        print("metainfo:", metainfo)
        folder_name = secret_name
        file_name = f"{folder_name}.txt"
        file_content = read_file_from_s3(bucket_name, folder_name, file_name)
        if file_content:
            # file_contents.append(file_content)
            file_contents.append(f"{file_name}: {file_content}")
        else:
            print(f"Error reading file for {secret_name}")

    if len(file_contents) >= 2:
        llm_input = "\n".join(file_contents)
        print("file_content: \n", file_content)
        llm_response = interact_with_llm_for_comparison(llm_input)
        print(llm_response)
        st.write(llm_response)
    else:
        print("Not enough files to compare.")
        st.error("Not enough files to compare.")


# retrieve_perf_metric_multiDatabase 에서 호출
# Performance Insights 데이터 가져오기
def get_performance_insights(cluster_id, instance_id, start_time, end_time):
    response = rds_client.describe_db_instances(DBInstanceIdentifier=instance_id)
    db_instance_resource_id = response["DBInstances"][0]["DbiResourceId"]

    response = rds_client.describe_db_clusters(DBClusterIdentifier=cluster_id)
    db_cluster_resource_id = response["DBClusters"][0]["DbClusterResourceId"]

    print("db_instance_resource_id:", db_instance_resource_id)

    response = pi_client.get_resource_metrics(
        ServiceType="RDS",
        Identifier=db_instance_resource_id,
        MetricQueries=[
            {"Metric": "os.cpuUtilization.user.avg"},
            {"Metric": "os.cpuUtilization.idle.avg"},
            {"Metric": "db.load.max"},
        ],
        StartTime=start_time,
        EndTime=end_time,
        PeriodInSeconds=60,  # 1분 간격으로 데이터 수집
        PeriodAlignment="END_TIME",
    )
    return response["MetricList"]


# retrieve_perf_metric_multiDatabase 에서 호출
def get_latest_metric_data(pi_client, db_instance_resource_id, start_time, end_time):
    # 현재 시간으로 초기화
    latest_end_time = end_time

    while True:
        try:
            response = pi_client.get_resource_metrics(
                ServiceType="RDS",
                Identifier=db_instance_resource_id,
                MetricQueries=[
                    {"Metric": "os.cpuUtilization.user.avg"},
                    {"Metric": "os.cpuUtilization.idle.avg"},
                    {"Metric": "db.load.max"},
                ],
                StartTime=start_time,
                EndTime=latest_end_time,
                PeriodInSeconds=300,  # 1분 간격으로 데이터 수집
                PeriodAlignment="END_TIME",
            )
            return response["MetricList"]
        except pi_client.exceptions.ResourceNotFoundException:
            # 데이터가 없는 경우, 종료 시간을 1분 앞당겨서 다시 시도
            latest_end_time = latest_end_time - datetime.timedelta(minutes=1)
            if latest_end_time < start_time:
                # 시작 시간보다 이전이면 데이터가 없는 것으로 간주하고 빈 리스트 반환
                return []


# retrieve_perf_metric_multiDatabase 에서 호출
# CloudWatch Enhanced Monitoring 데이터 가져오기
def get_enhanced_monitoring(cluster_id, instance_id, start_time, end_time):
    response = cw_client.get_metric_data(
        MetricDataQueries=[
            {
                "Id": "cpu_utilization",
                "MetricStat": {
                    "Metric": {
                        "Namespace": "AWS/RDS",
                        "MetricName": "CPUUtilization",
                        "Dimensions": [
                            {"Name": "DBInstanceIdentifier", "Value": instance_id}
                        ],
                    },
                    "Period": 300,
                    "Stat": "Maximum",
                },
                "ReturnData": True,
            },
            {
                "Id": "memory_usage",
                "MetricStat": {
                    "Metric": {
                        "Namespace": "AWS/RDS",
                        "MetricName": "FreeableMemory",
                        "Dimensions": [
                            {"Name": "DBInstanceIdentifier", "Value": instance_id}
                        ],
                    },
                    "Period": 300,
                    "Stat": "Maximum",
                },
                "ReturnData": True,
            },
        ],
        StartTime=start_time,
        EndTime=end_time,
    )
    return response["MetricDataResults"]


# retrieve_perf_metric_multiDatabase 에서 호출
# CPU 과부하 확인 : cpu capacity는 찾아야함
def check_cpu_overload(cluster_id, instance_id, pi_data, cpu_capacity):
    overload_detected = False

    # DB 인스턴스 정보 가져오기
    response = rds_client.describe_db_instances(DBInstanceIdentifier=instance_id)
    db_instance = response["DBInstances"][0]

    # 인스턴스가 속한 클러스터 ID 확인
    instance_cluster_identifier = db_instance["DBClusterIdentifier"]

    # 클러스터 ID 일치 여부 확인
    if instance_cluster_identifier == cluster_id:
        db_instance_class = db_instance["DBInstanceClass"]

        # 인스턴스 클래스에서 vCPU 수 가져오기
        instance_info = rds_client.describe_orderable_db_instance_options(
            Engine="aurora-mysql", DBInstanceClass=db_instance_class
        )
        max_vcpu = instance_info["OrderableDBInstanceOptions"][0]["VCPUCount"]
    print("max vcpu: ", max_vcpu)

    for metric in pi_data:
        if metric["Key"]["Metric"] == "db.load.avg":
            for datapoint in metric["DataPoints"]:
                if datapoint["Value"] > max_vcpu:
                    overload_detected = True
                    print(
                        f"CPU Overload Detected at {datapoint['Timestamp']}: {datapoint['Value']} > {max_vcpu}"
                    )
    if not overload_detected:
        print("No CPU Overload Detected")


# retrieve_perf_metric_multiDatabase 에서 호출
def upload_to_s3_em(
    cluster_id, instance_id, data, bucket_name, bucket_path, object_key
):
    s3_client = boto3.client("s3")

    # 데이터를 CSV 형식으로 변환
    csv_data = StringIO()
    writer = csv.writer(csv_data)

    # 헤더 작성
    header = ["metric", "timestamp", "value"]
    writer.writerow(header)

    for result in data:
        metric_name = result["Label"]
        timestamps = result["Timestamps"]
        values = result["Values"]

        for timestamp, value in zip(timestamps, values):
            row = [
                cluster_id,
                instance_id,
                metric_name,
                timestamp.strftime("%Y-%m-%d %H:%M"),
                value,
            ]
            writer.writerow(row)

    csv_data.seek(0)

    # S3에 업로드
    object_path = f"{bucket_path}/{object_key}"
    s3_client.put_object(Bucket=bucket_name, Key=object_path, Body=csv_data.getvalue())
    print(f"Data {object_key} uploaded to {bucket_name}/{bucket_path}/{object_key}")


# retrieve_perf_metric_multiDatabase 에서 호출
def upload_to_s3_pi(
    cluster_id, instance_id, data, bucket_name, bucket_path, object_key
):
    s3_client = boto3.client("s3")

    # 데이터를 CSV 형식으로 변환
    csv_data = StringIO()
    writer = csv.writer(csv_data)

    # 헤더 작성
    header = ["metric", "timestamp", "value"]
    writer.writerow(header)

    for result in data:
        metric_name = result["Key"]["Metric"]
        # print(result['DataPoints'])
        timestamps = [dp["Timestamp"] for dp in result["DataPoints"]]

        values = [dp.get("Value") for dp in result["DataPoints"] if "Value" in dp]

        for timestamp, value in zip(timestamps, values):
            # row = [metric_name, timestamp.isoformat(), value]
            row = [
                cluster_id,
                instance_id,
                metric_name,
                timestamp.strftime("%Y-%m-%d %H:%M"),
                value,
            ]
            # print(timestamp.strftime('%Y-%m-%d %H:%M'))
            writer.writerow(row)

    csv_data.seek(0)

    # S3에 업로드
    object_path = f"{bucket_path}/{object_key}"
    s3_client.put_object(Bucket=bucket_name, Key=object_path, Body=csv_data.getvalue())
    print(f"Data {object_key} uploaded to {bucket_name}/{bucket_path}/{object_key}")


# retrieve_perf_metric_multiDatabase 에서 호출
def check_table_exists(database_name, table_name):
    try:
        athena_client.get_table_metadata(
            CatalogName="AwsDataCatalog", DatabaseName="sales", TableName=table_name
        )
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "EntityNotFoundException":
            athena_client.start_query_execution(
                QueryString=f"CREATE EXTERNAL TABLE  {table_name}",
                ResultConfiguration={"OutputLocation": s3_bucket_meta_path},
            )


def retrieve_perf_metric_multiDatabase(keyword, start_time, end_time, user_query):
    # 시간세팅  start_time, end_time이 비어있으면
    if start_time == "" and end_time == "":
        print("시간정보가 없어요!")
        # 현재 시간
        now = datetime.datetime.now()

        print("현재시간:", now)  #
        # 10분 전 시간
        ten_mins_ago = now - datetime.timedelta(minutes=10)

        # 원하는 형식으로 변환
        end_time = now.strftime("%Y-%m-%d %H:%M")
        start_time = ten_mins_ago.strftime("%Y-%m-%d %H:%M")

    print("start_time:", start_time)
    print("end_time:", end_time)
    # 데이터베이스 생성 (존재하지 않는 경우)
    try:
        athena_client.get_database(
            CatalogName="AwsDataCatalog", DatabaseName=database_name
        )
        print("create database")
    except ClientError as e:
        if e.response["Error"]["Code"] == "EntityNotFoundException":
            athena_client.start_query_execution(
                QueryString=f"CREATE DATABASE {database_name}",
                ResultConfiguration={"OutputLocation": s3_bucket_meta_path},
            )
        st.error(f"Error reading file from S3: {e}")

    # 테이블이 존재하는 경우 삭제
    if check_table_exists(database_name, pi_table_name):
        athena_client.start_query_execution(
            QueryString=f"DROP TABLE {database_name}.{pi_table_name}",
            ResultConfiguration={"OutputLocation": s3_bucket_meta_path},
        )
        print(f"{database_name}.{pi_table_name} dropped!")

    if check_table_exists(database_name, em_table_name):
        athena_client.start_query_execution(
            QueryString=f"DROP TABLE {database_name}.{em_table_name}",
            ResultConfiguration={"OutputLocation": s3_bucket_meta_path},
        )
        print(f"{database_name}.{em_table_name} dropped!")

    # 테이블 생성
    QueryString_input = f"""
        CREATE EXTERNAL TABLE {database_name}.{pi_table_name} (
            cluster_id string,
            instance_id string,
            metric string,
            timestamp string,
            value double
        )
        ROW FORMAT DELIMITED
        FIELDS TERMINATED BY ','
        LOCATION '{s3_bucket_table_pi_path}/'
        TBLPROPERTIES ('skip.header.line.count'='1')
        """
    # print(QueryString_input)
    athena_client.start_query_execution(
        QueryString=QueryString_input,
        ResultConfiguration={"OutputLocation": s3_bucket_meta_path},
    )

    # print('pi table created')
    QueryString_input = f"""
        CREATE EXTERNAL TABLE {database_name}.{em_table_name} (
            cluster_id string,
            instance_id string,
            metric string,
            timestamp string,
            value double
        )
        ROW FORMAT DELIMITED
        FIELDS TERMINATED BY ','
        LOCATION '{s3_bucket_table_em_path}/'
        TBLPROPERTIES ('skip.header.line.count'='1')
        """
    # print (QueryString_input)
    athena_client.start_query_execution(
        QueryString=QueryString_input,
        ResultConfiguration={"OutputLocation": s3_bucket_meta_path},
    )
    # print('QueryString',QueryString_input)
    secret_lists = get_secrets_by_keyword(keyword)
    for secret_name in secret_lists:
        secret_values = get_secret(secret_name)
        print(secret_values)  # test
        cluster_id = secret_values["dbClusterIdentifier"]
        print("clusterid:", cluster_id)
        response = rds_client.describe_db_clusters(DBClusterIdentifier=cluster_id)
        instances = response["DBClusters"][0]["DBClusterMembers"]
        for instance in instances:
            instance_id = instance["DBInstanceIdentifier"]
            print("instance_id:", instance_id)
            pi_data = get_performance_insights(
                cluster_id, instance_id, start_time, end_time
            )
            em_data = get_enhanced_monitoring(
                cluster_id, instance_id, start_time, end_time
            )
            upload_to_s3_em(
                cluster_id,
                instance_id,
                em_data,
                s3_bucket_name,
                f"{database_name}/data/enhanced_monitoring_data",
                f"{cluster_id}_{em_table_name}.csv",
            )
            upload_to_s3_pi(
                cluster_id,
                instance_id,
                pi_data,
                s3_bucket_name,
                f"{database_name}/data/performance_insight_monitoring_data",
                f"{cluster_id}_{pi_table_name}.csv",
            )

    user_query += f" 그리고 enhanced metric data 테이블에서 {start_time} 와 {end_time} 사이의 시간대에 cpu, memory정보를 가져오세요! 필요할 경우 중첩 쿼리로 특정메트릭값이 얼마 이상인 값만 가져올수도 있습니다. "
    query_athena_table(database_name, user_query)


# retrieve_perf_metric_multiDatabase 에서 호출
def query_athena_table(database_name, user_query):
    if user_query:
        print("query_athena_table")
        llm_response = interact_with_llm_athena(database_name, user_query)
        print("llm_response : ", llm_response)
        # Convert multiline llm_response to single line
        # st.write(f"LLM Response: {llm_response}")
        # print(llm_response)
        # Extract SQL command from LLM response
        sql_command_match = re.search(
            r"<begin sql>(.*?)<\s?/end sql>", llm_response, re.DOTALL | re.IGNORECASE
        )
        # sql_command_match = re.sub("\n", "", sql_command_match)
        # print(sql_command_match)
        print("sql_command_match : ", sql_command_match)
        if sql_command_match:
            sql_command = sql_command_match.group(1).strip()
            print(sql_command)
            try:
                # 쿼리 실행
                response = athena_client.start_query_execution(
                    QueryString=sql_command,
                    QueryExecutionContext={"Database": database_name},
                    ResultConfiguration={
                        "OutputLocation": f"s3://{s3_bucket_name}/{database_name}/query_results/"
                    },
                )

                # 쿼리 실행 상태 확인
                query_execution_id = response["QueryExecutionId"]
                while True:
                    status = athena_client.get_query_execution(
                        QueryExecutionId=query_execution_id
                    )
                    state = status["QueryExecution"]["Status"]["State"]
                    if state == "SUCCEEDED":
                        break
                    elif state == "FAILED":
                        raise Exception(
                            f"Query failed: {status['QueryExecution']['Status']['StateChangeReason']}"
                        )
                    time.sleep(1)

                # 쿼리 결과 가져오기
                result = athena_client.get_query_results(
                    QueryExecutionId=query_execution_id
                )
                rows = result["ResultSet"]["Rows"]
                headers = [
                    header["Name"]
                    for header in result["ResultSet"]["ResultSetMetadata"]["ColumnInfo"]
                ]
                data = [
                    [row["VarCharValue"] for row in rec["Data"]] for rec in rows[1:]
                ]
                print(data)
                df = pd.DataFrame(data, columns=headers)

                # DataFrame을 문자열로 변환하여 반환
                st.write(df)
                return df.to_string(index=False)
            except Exception as e:
                print(f"Error querying Athena table: {e}")
                return None
        else:
            st.warning("No SQL command found in LLM response.")
            print("No SQL command found in LLM response.")


def get_athena_database_info(database_name):
    try:
        # 데이터베이스 내 테이블 목록 조회
        # query = f"SHOW TABLES IN {database_name}"
        # table_list_df = query_athena_table(database_name, query)
        table_list = {
            "enhanced_monitoring_data",
            "performance_insights_data",
        }  # table_list_df['tab_name'].tolist()

        # 각 테이블의 컬럼 정보 조회
        table_info = []
        for table_name in table_list:
            query = f"SHOW COLUMNS IN {database_name}.{table_name}"
            try:
                # 쿼리 실행
                response = athena_client.start_query_execution(
                    QueryString=query,
                    QueryExecutionContext={"Database": database_name},
                    ResultConfiguration={
                        "OutputLocation": f"s3://{s3_bucket_name}/{database_name}/query_results/"
                    },
                )

                # 쿼리 실행 상태 확인
                query_execution_id = response["QueryExecutionId"]
                while True:
                    status = athena_client.get_query_execution(
                        QueryExecutionId=query_execution_id
                    )
                    state = status["QueryExecution"]["Status"]["State"]
                    if state == "SUCCEEDED":
                        break
                    elif state == "FAILED":
                        raise Exception(
                            f"Query failed: {status['QueryExecution']['Status']['StateChangeReason']}"
                        )
                    time.sleep(1)

                # 쿼리 결과 가져오기
                result = athena_client.get_query_results(
                    QueryExecutionId=query_execution_id
                )
                rows = result["ResultSet"]["Rows"]
                headers = [
                    header["Name"]
                    for header in result["ResultSet"]["ResultSetMetadata"]["ColumnInfo"]
                ]
                data = [
                    [row["VarCharValue"] for row in rec["Data"]] for rec in rows[0:]
                ]
                column_info_df = pd.DataFrame(data, columns=headers)
                column_info_df["data_type"] = [
                    rec["Data"][1]["VarCharValue"] for rec in rows[1:]
                ]  # 데이터 유형 추가
            except Exception as e:
                print(f"Error querying Athena table: {e}")

            table_info.append(
                f"Table: {table_name}\n{column_info_df.to_string(index=False)}\n"
            )

        table_info_str = "\n".join(table_info)
        return table_info_str

    except Exception as e:
        print(f"Error getting Athena table information: {e}")
        st.error(f"Error getting Athena table information: {e}")
        return None


def explain_plan_query(keyword, user_query):
    secret_name = keyword
    print("explain_plan_query executed!")
    user_query += " when you get query , add explain before query! "
    if user_query:
        llm_response = interact_with_llm(secret_name, user_query)
        # Convert multiline llm_response to single line
        # st.write(f"LLM Response: {llm_response}")
        # print(llm_response)
        # Extract SQL command from LLM response
        sql_command_match = re.search(
            r"<begin sql>(.*?)<\s?/end sql>", llm_response, re.DOTALL | re.IGNORECASE
        )
        # sql_command_match = re.sub("\n", "", sql_command_match)
        # print(sql_command_match)
        prompt2 = ""
        if sql_command_match:
            sql_command = sql_command_match.group(1).strip()
            print(sql_command + f" on {secret_name}")
            try:

                connection = connect_to_db(secret_name)
                cursor = connection.cursor()
                cursor.execute(sql_command)
                result = cursor.fetchall()
                columns = cursor.column_names
                df = pd.DataFrame(result, columns=columns)

                # 너비를 최대 200자리로 설정
                pd.set_option("display.max_rows", 200)
                # 최대 열 수를 20으로 설정
                pd.set_option("display.max_columns", 20)
                # 전체 너비를 200자리로 설정
                pd.set_option("display.width", 200)

                st.write(df)

                prompt2 = "please explain details with this query plan :" + str(result)
                llm_response2 = interact_with_general_llm(prompt2)
                st.write(llm_response2)

            except Exception as e:
                print(f"Error executing SQL command: {e}")
        else:
            st.warning("No SQL command found in LLM response.")
            print("No SQL command found in LLM response.")


tool_config = {
    "tools": [
        {
            "toolSpec": {
                "name": "get_price",
                "description": "Get the price with given parameter fruit",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "fruit": {
                                "type": "string",
                                "description": "input parameter is fruit",
                            }
                        },
                        "required": ["fruit"],
                    }
                },
            }
        },
        {
            "toolSpec": {
                "name": "get_database_info",
                "description": "Get the database schema information such as table_name, column name and so on ,with the given secret name and this function is invoked only when you are asked about get schema information",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "secret_name": {
                                "type": "string",
                                "description": "The secret name for database connection",
                            }
                        },
                        "required": ["secret_name"],
                    }
                },
            }
        },
        {
            "toolSpec": {
                "name": "execute_sql",
                "description": "Execute a SQL query on the database specified by the secret name. you can join tables and retrieve data with various functions and also change schema such as alter table add or create index and etc. and you can use this function when you are asked about top query",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "secret_name": {
                                "type": "string",
                                "description": "The secret name for database connection. Cluster, Database or DB may be same meaning as secret name",
                            },
                            "user_query": {
                                "type": "string",
                                "description": "The SQL query to execute",
                            },
                        },
                        "required": ["secret_name", "user_query"],
                    }
                },
            }
        },
        {
            "toolSpec": {
                "name": "execute_sql_multiDatabase",
                "description": "Execute a SQL query on multiple databases specified by the keyword.In the case you are asked about all clusters or databases, you can use this function",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "keyword": {
                                "type": "string",
                                "description": "Keyword to identify multiple databases",
                            },
                            "user_query": {
                                "type": "string",
                                "description": "The SQL query to execute",
                            },
                        },
                        "required": ["keyword", "user_query"],
                    }
                },
            }
        },
        {
            "toolSpec": {
                "name": "compare_database_info",
                "description": "Compare database information for the databases identified by the keyword",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "keyword": {
                                "type": "string",
                                "description": "Keyword to identify multiple databases",
                            }
                        },
                        "required": ["keyword"],
                    }
                },
            }
        },
        {
            "toolSpec": {
                "name": "retrieve_perf_metric_multiDatabase",
                "description": "Retrieve performance metrics for multiple databases within a time range. but not the case that you are asked about top query",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "keyword": {
                                "type": "string",
                                "description": "Keyword to identify multiple databases",
                            },
                            "start_time": {
                                "type": "string",
                                "description": "Start time for the metrics retrieval",
                            },
                            "end_time": {
                                "type": "string",
                                "description": "End time for the metrics retrieval",
                            },
                            "user_query": {
                                "type": "string",
                                "description": "The query to execute for retrieving metrics",
                            },
                        },
                        "required": ["keyword", "start_time", "end_time", "user_query"],
                    }
                },
            }
        },
        {
            "toolSpec": {
                "name": "query_athena_table",
                "description": "Execute a query on an Athena table",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "database_name": {
                                "type": "string",
                                "description": "The name of the Athena database",
                            },
                            "user_query": {
                                "type": "string",
                                "description": "The query to execute",
                            },
                        },
                        "required": ["database_name", "user_query"],
                    }
                },
            }
        },
        {
            "toolSpec": {
                "name": "check_cpu_overload",
                "description": "Check CPU overload for a database",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "database_name": {
                                "type": "string",
                                "description": "The name of the database",
                            },
                            "user_query": {
                                "type": "string",
                                "description": "The query to execute for checking CPU overload",
                            },
                        },
                        "required": ["database_name", "user_query"],
                    }
                },
            }
        },
        {
            "toolSpec": {
                "name": "explain_plan_query",
                "description": "Get the execution plan for a SQL query when you are asked about analyzing execution plan of query",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "keyword": {
                                "type": "string",
                                "description": "Keyword to identify the database",
                            },
                            "user_query": {
                                "type": "string",
                                "description": "The SQL query to get the execution plan for",
                            },
                        },
                        "required": ["keyword", "user_query"],
                    }
                },
            }
        },
    ]
}


def main():

    # 사이드바 설정
    st.sidebar.title("Settings")

    # 채팅 입력
    prompt = st.chat_input("What would you like to ask about Aurora MySQL management?")

    # 사이드바 하단에 파일 업로더 배치
    st.sidebar.markdown("---")  # 구분선 추가
    st.sidebar.subheader("SQL File Upload")
    uploaded_file = st.sidebar.file_uploader("Choose a SQL file", type=["sql"])

    query = ""
    displayed_query = ""
    if uploaded_file is not None:
        query = str(uploaded_file.read(), "utf-8")
        st.sidebar.success("File successfully uploaded!")
        # 메인 영역에 쿼리 표시 영역 생성
        query_area = st.container()
        with query_area:
            displayed_query = st.text_area("SQL Query", value=query, height=200)
        #
        print("uploaded query:-----  ", query)

    if prompt is not None:
        print("if prompt:")
        if displayed_query:
            combined_prompt = f"{prompt}\n\nSQL Query:\n{displayed_query}"
        else:
            combined_prompt = prompt
        print("prompt:-----", combined_prompt)

        st.session_state.messages.append({"role": "user", "content": combined_prompt})
        with st.chat_message("user"):
            st.markdown(combined_prompt)

        chat_with_claude(combined_prompt, tool_config)


if __name__ == "__main__":
    if runtime.exists():
        main()
    else:
        sys.argv = ["streamlit", "run", sys.argv[0]]
        sys.exit(stcli.main())
