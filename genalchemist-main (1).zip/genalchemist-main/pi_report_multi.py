import streamlit as st
import boto3
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import pytz

# Streamlit 앱 제목 설정
st.title('AWS Aurora MySQL Performance Insights')

# AWS 리전 목록
regions = ['us-east-1', 'us-west-2', 'ap-northeast-2']

# 사이드바에서 사용자 입력 받기
region_name = st.sidebar.selectbox('AWS Region', regions)

# AWS RDS 클라이언트 생성
rds_client = boto3.client('rds', region_name=region_name)

# Aurora MySQL 클러스터 목록 가져오기
def get_aurora_clusters():
    clusters = []
    paginator = rds_client.get_paginator('describe_db_clusters')
    for page in paginator.paginate():
        for cluster in page['DBClusters']:
            if cluster['Engine'].startswith('aurora-mysql'):
                clusters.append(cluster['DBClusterIdentifier'])
    return clusters

clusters = get_aurora_clusters()
selected_clusters = st.sidebar.multiselect('Select DB Clusters', clusters)

# 선택된 클러스터의 인스턴스 목록 가져오기
instances = []
for cluster in selected_clusters:
    response = rds_client.describe_db_instances(Filters=[{'Name': 'db-cluster-id', 'Values': [cluster]}])
    instances.extend([instance['DBInstanceIdentifier'] for instance in response['DBInstances']])

# 날짜 및 시간 범위 선택
end_time = st.sidebar.date_input("End Date", datetime.now(pytz.UTC).date())
end_time_hour = st.sidebar.time_input("End Time", datetime.now(pytz.UTC).time())
end_time = datetime.combine(end_time, end_time_hour).replace(tzinfo=pytz.UTC)

start_time = st.sidebar.date_input("Start Date", end_time.date() - timedelta(days=1))
start_time_hour = st.sidebar.time_input("Start Time", end_time.time())
start_time = datetime.combine(start_time, start_time_hour).replace(tzinfo=pytz.UTC)

# 시작 시간이 종료 시간보다 늦거나, 7일을 초과하는 경우 처리
if start_time > end_time:
    st.sidebar.error("Start date/time must be before end date/time.")
elif end_time - start_time > timedelta(days=7):
    st.sidebar.error("Date range cannot exceed 7 days.")
else:
    # "Analyze" 버튼
    if st.sidebar.button('Analyze'):
        # Performance Insights 데이터 가져오기 및 그래프 그리기
        pi_client = boto3.client('pi', region_name=region_name)

        fig, ax = plt.subplots(figsize=(12, 6))
        all_data = []

        for instance in instances:
            try:
                response = rds_client.describe_db_instances(DBInstanceIdentifier=instance)
                resource_id = response['DBInstances'][0]['DbiResourceId']

                pi_response = pi_client.get_resource_metrics(
                    ServiceType='RDS',
                    Identifier=resource_id,
                    StartTime=start_time,
                    EndTime=end_time,
                    PeriodInSeconds=3600,  # 1시간 간격으로 데이터 가져오기
                    MetricQueries=[
                        {
                            'Metric': 'db.load.avg',
                            'GroupBy': {'Group': 'db.wait_event'}
                        },
                    ]
                )

                data = pi_response['MetricList'][0]['DataPoints']
                df = pd.DataFrame(data)
                df['Timestamp'] = pd.to_datetime(df['Timestamp'])
                df.set_index('Timestamp', inplace=True)
                df.sort_index(inplace=True)
                df['Instance'] = instance

                ax.plot(df.index, df['Value'], label=instance)
                all_data.append(df)

            except Exception as e:
                st.error(f"Error retrieving data for instance {instance}: {str(e)}")

        ax.set_title('AWS Aurora MySQL Performance Insights - Database Load')
        ax.set_xlabel('Time')
        ax.set_ylabel('Average Active Sessions')
        ax.grid(True)
        plt.xticks(rotation=45)
        plt.legend()
        plt.tight_layout()

        # Streamlit에 그래프 표시
        st.pyplot(fig)

        # 모든 데이터 합치기
        if all_data:
            combined_df = pd.concat(all_data)

            # 통계 정보 표시
            st.subheader('Performance Statistics')
            stats = combined_df.groupby('Instance')['Value'].agg(['mean', 'max', 'min']).reset_index()
            stats.columns = ['Instance', 'Average Load', 'Maximum Load', 'Minimum Load']
            st.dataframe(stats)

            # Raw Data 표시
            st.subheader('Raw Data')
            st.dataframe(combined_df)
        else:
            st.warning("No data available for the selected instances.")

# 사용 설명 추가
st.sidebar.markdown("""
## How to use:
1. Select the AWS Region from the dropdown.
2. Choose one or more DB Clusters.
3. Set the start and end dates and times for the data you want to analyze (max 7 days).
4. Click the 'Analyze' button to generate the performance insights.
""")