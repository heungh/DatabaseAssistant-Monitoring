import boto3
import sys
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed


def perform_blue_green_deployment(account):
    print(f"\nProcessing account: {account['account_id']}")
    session = boto3.Session(
        aws_access_key_id=account["access_key"],
        aws_secret_access_key=account["secret_key"],
        region_name=account["region"],
    )
    rds_client = session.client("rds", region_name=account["region"])

    response = rds_client.describe_blue_green_deployments()
    deployment_cluster_map = {
        deployment["BlueGreenDeploymentIdentifier"]: deployment[
            "BlueGreenDeploymentName"
        ]
        for deployment in response["BlueGreenDeployments"]
    }

    results = []
    for identifier, cluster_name in deployment_cluster_map.items():
        try:
            status = rds_client.describe_blue_green_deployments(
                BlueGreenDeploymentIdentifier=identifier
            )["BlueGreenDeployments"][0]["Status"]

            if status == "AVAILABLE":
                response = rds_client.switchover_blue_green_deployment(
                    BlueGreenDeploymentIdentifier=identifier
                )
                results.append(
                    f"블루그린 [{identifier}] {cluster_name} 스위치오버 완료"
                )
            else:
                results.append(
                    f"블루그린 [{identifier}] {cluster_name} 이미 스위치오버가 끝났거나 시작되어 처리중입니다."
                )

        except Exception as e:
            results.append(f"Error: {e}")

    return results


def read_accounts_from_csv(file_path):
    accounts = []
    with open(file_path, "r") as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            accounts.append(
                {
                    "account_id": row["account_id"],
                    "access_key": row["access_key"],
                    "secret_key": row["secret_key"],
                    "region": row["region"],
                }
            )
    return accounts


def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <path_to_csv_file>")
        sys.exit(1)

    csv_file_path = sys.argv[1]
    accounts = read_accounts_from_csv(csv_file_path)

    # 병렬 처리를 위한 ThreadPoolExecutor 설정
    max_workers = 20  # 동시에 처리할 최대 작업 수
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_account = {
            executor.submit(perform_blue_green_deployment, account): account
            for account in accounts
        }

        for future in as_completed(future_to_account):
            account = future_to_account[future]
            try:
                results = future.result()
                for result in results:
                    print(result)
            except Exception as exc:
                print(f'{account["account_id"]} generated an exception: {exc}')


if __name__ == "__main__":
    main()
