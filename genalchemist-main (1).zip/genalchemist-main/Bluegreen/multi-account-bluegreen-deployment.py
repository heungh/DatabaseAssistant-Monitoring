import boto3
import sys
import csv


def perform_blue_green_deployment(session, region_name):
    # AWS RDS 클라이언트 생성
    rds_client = session.client("rds", region_name=region_name)

    # describe-blue-green-deployments API 호출
    response = rds_client.describe_blue_green_deployments()

    # BlueGreenDeploymentIdentifier 및 cluster이름 추출
    deployment_cluster_map = {
        deployment["BlueGreenDeploymentIdentifier"]: deployment[
            "BlueGreenDeploymentName"
        ]
        for deployment in response["BlueGreenDeployments"]
    }

    # BlueGreenDeploymentIdentifier 값 출력
    for identifier, cluster_name in deployment_cluster_map.items():
        try:
            status = rds_client.describe_blue_green_deployments(
                BlueGreenDeploymentIdentifier=identifier
            )["BlueGreenDeployments"][0]["Status"]

            if status == "AVAILABLE":
                response = rds_client.switchover_blue_green_deployment(
                    BlueGreenDeploymentIdentifier=identifier
                )
                print(f"블루그린 [{identifier}] {cluster_name} 스위치오버 완료")
            else:
                print(
                    f"블루그린 [{identifier}] {cluster_name} 이미 스위치오버가 끝났거나 시작되어 처리중입니다."
                )

        except Exception as e:
            print(f"Error: {e}")


def read_accounts_from_csv(file_path):
    accounts = []
    with open(file_path, "r") as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            accounts.append(
                {
                    "account_id": row["account_id"],
                    "access_key": row["access_key"],
                    "secret_key": row["secret_key"],
                    "region": row["region"],
                }
            )
    return accounts


def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <path_to_csv_file>")
        sys.exit(1)

    csv_file_path = sys.argv[1]
    accounts = read_accounts_from_csv(csv_file_path)

    for account in accounts:
        print(f"\nProcessing account: {account['account_id']}")

        # 계정별 세션 생성
        session = boto3.Session(
            aws_access_key_id=account["access_key"],
            aws_secret_access_key=account["secret_key"],
            region_name=account["region"],
        )

        perform_blue_green_deployment(session, account["region"])


if __name__ == "__main__":
    main()
